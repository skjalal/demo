package com.example.persistance;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.domain.User;

@Component
public class DbSeeders implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;

	@Override
	public void run(String... args) throws Exception {
		User jalal = new User("Jalal", "Aurangabad", "431001");
		User ranjan = new User("Ranjan", "Udeesa", "77777");
		User mahesh = new User("Mahesh", "TS", "500081");
		List<User> users = new ArrayList<>();
		users.add(mahesh);
		users.add(ranjan);
		users.add(jalal);
		userRepository.saveAll(users);
	}

}
