package com.example.persistance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.domain.User;

@Repository("userRepository")
public interface UserRepository extends JpaRepository<User, Long> {

}