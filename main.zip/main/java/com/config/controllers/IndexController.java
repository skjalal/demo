package com.config.controllers;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
	private final Logger log = Logger.getLogger(IndexController.class);

	@RequestMapping("/")
	public String index() {
		log.info("Enter into Index Contrller...!");
		String index = "login";
		log.info("Ends Of Index Contrller...!");
		return index;
	}
}