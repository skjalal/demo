# BootstrapSpringProject
Bootstrap and DataTables in a Spring MVC Application

Please check the tutorial on my blog: http://alanterriaga.com
